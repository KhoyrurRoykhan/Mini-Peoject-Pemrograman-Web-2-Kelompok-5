                <div class="box2E">
                    <div class="data2E">
                        <h1>MENU PETUGAS</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"> <?= $data['petugas']['nama_petugas']?> </h2>
                          <div class="table1B">
                            <p>ID petugas : <?=$data['petugas']['id_petugas']?>
                            <p>Nama petugas : <?=$data['petugas']['nama_petugas']?></p>
                            <p>Alamat petugas : <?=$data['petugas']['alamat']?>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>



