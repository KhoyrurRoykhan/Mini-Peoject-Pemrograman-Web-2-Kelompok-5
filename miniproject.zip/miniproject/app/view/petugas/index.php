                <div class="box2E">
                    <div class="data2E">
                        <h1>MENU PETUGAS</h1>
                            <table class="table2A">
                                    <tr?>
                                        <td class="tabel3A">ID PETUGAS</td>
                                        <td class="tabel3A">NAMA PETUGAS</td>
                                        <td class="tabel3A">AKSI</td>
                                    </tr>
                                <?php foreach ($data['petugas'] as $petugas) : ?>
                            
                                    <tr?>
                                        <td class="tabel4A"><?= $petugas['id_petugas']?></td>
                                        <td class="tabel4A"><?= $petugas['nama_petugas']?></td>
                                        <td class="tabel4A"><button class="btn1"><a href="<?= BASEURL?>/petugas/detail/<?=$petugas['id_petugas']?>">
                                        Detail</a></button></td>
                                    </tr>
                                    
                                <?php endforeach; ?>
                            </table>
                    </div>
                </div>
            