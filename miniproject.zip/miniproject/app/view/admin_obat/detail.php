                <div class="box2C">
                    <div class="data2C">
                        <h1>MENU OBAT</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"> <?= $data['obat']['nama_obat']?> </h2>
                            <div class="table1B">
                                <p>ID Obat : <?=$data['obat']['id_obat']?></p>
                                <p>Nama Obat : <?=$data['obat']['nama_obat']?></p>
                                <p>Jenis Obat : <?=$data['obat']['jenis_obat']?></p>
                                <p>Sediaan : <?=$data['obat']['sediaan']?></p>
                                <p>Dosis Anak : <?=$data['obat']['dosis_anak']?></p>
                                <p>Dosis Dewasa : <?=$data['obat']['dosis_dewasa']?></p>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>