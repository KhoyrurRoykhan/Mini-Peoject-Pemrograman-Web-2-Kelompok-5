
                <div class="box2D">
                    <div class="data2D">
                        <h1>MENU PASIEN</h1>
                        <div class="table1A">
                                <table class="table2A">
                                            <tr?>
                                                <td class="tabel3A">ID PASIEN</td>
                                                <td class="tabel3A">NAMA PASIEN</td>
                                                <td class="tabel3A">AKSI</td>
                                            </tr>
                                    <?php foreach ($data['pasien'] as $pasien) : ?>
                                        
                                            <tr?>
                                                <td class="tabel4A"><?= $pasien['id_pasien']?></td>
                                                <td class="tabel4A"><?= $pasien['nama_pasien']?></td>
                                                <td class="tabel4A"><a href="<?= BASEURL?>/pasien/detail/<?=$pasien['id_pasien']?>">detail</a></td>
                                            </tr>
                                        
                                    <?php endforeach; ?>
                                    </table>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
