
                <div class="box2E">
                    <div class="data2E">
                        <h1>MENU POLI</h1>
                        <div class="table1A">
                            <table class="table2A">
                                    <tr?>
                                        <td class="tabel3A">ID POLI</td>
                                        <td class="tabel3A">NAMA POLI</td>
                                        <td class="tabel3A">AKSI</td>
                                    </tr>
                                <?php foreach ($data['poli'] as $poli) : ?>
                            
                                    <tr?>
                                        <td class="tabel4A"><?= $poli['id_poli']?></td>
                                        <td class="tabel4A"><?= $poli['nama_poli']?></td>
                                        <td class="tabel4A"><a href="<?= BASEURL?>/poli/detail/<?=$poli['id_poli']?>">detail</a></td>
                                    </tr>
                                    
                                <?php endforeach; ?>
                            </table>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
