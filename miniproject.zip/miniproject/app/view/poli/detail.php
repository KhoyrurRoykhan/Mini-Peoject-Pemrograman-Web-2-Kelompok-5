
                <div class="box2E">
                    <div class="data2E">
                        <h1>MENU POLI</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"> <?= $data['poli']['nama_poli']?> </h2>
                          <div class="table1B">
                            <p>Nama Poli : <?=$data['poli']['nama_poli']?></p>
                            <p>ID Poli : <?=$data['poli']['id_poli']?></p>
                            <p>Keterangan : xxxxxxxxxxxxxxx</p>
                            <p>Dokter : <?=$data['poli']['nama_dokter']?></p>

                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
