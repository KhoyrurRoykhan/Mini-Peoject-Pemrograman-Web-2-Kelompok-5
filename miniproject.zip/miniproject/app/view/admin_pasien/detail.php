
                <div class="box2D">
                    <div class="data2D">
                        <h1>MENU PASIEN</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"><?= $data['pasien']['nama_pasien']?> </h2>
                            <div class="table1B">
                                <p>Nama Pasien : <?=$data['pasien']['nama_pasien']?></p>
                                <p>ID Pasien : <?=$data['pasien']['id_pasien']?></p>
                                <p>Jenis Kelamin : <?=$data['pasien']['jenis_kelamin']?></p>
                                <p>Alamat : <?=$data['pasien']['alamat']?></p>
                                <p>Poli : <?=$data['pasien']['nama_poli']?></p>
                                <p>Petugas : <?=$data['pasien']['nama_petugas']?></p>
                                <p>Dokter : <?=$data['pasien']['nama_dokter']?></p>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>

