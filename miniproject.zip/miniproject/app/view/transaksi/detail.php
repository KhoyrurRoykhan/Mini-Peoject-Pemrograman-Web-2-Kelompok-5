            <div class="box2E">
                    <div class="data2E">
                        <h1>MENU TRANSAKSI</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"><?= $data['transaksi']['id_transaksi']?> </h2>
                          <div class="table1B">
                            <p>Id Pasien : <?=$data['transaksi']['id_pasien']?></p>
                            <p>Nama Pasien : <?=$data['transaksi']['nama_pasien']?></p>
                            <p>Nama Dokter : <?=$data['transaksi']['nama_dokter']?></p>
                            <p>Nama Obat : <?=$data['transaksi']['nama_obat']?></p>

                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>