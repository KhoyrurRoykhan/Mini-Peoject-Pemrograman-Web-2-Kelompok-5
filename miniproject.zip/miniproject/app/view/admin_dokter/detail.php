
                <div class="box2C">
                    <div class="data2C">
                        <h1>MENU DOKTER</h1>
                        <p class="paragraf1B">
                          <h2 class="nama1A"> <?= $data['dokter']['nama_dokter']?> </h2>
                            <div class="table1B">
                                <p>Nama Dokter : <?=$data['dokter']['nama_dokter']?></p>
                                <p>ID Pasien : <?=$data['dokter']['id_dokter']?></p>
                                <p>Alamat : <?=$data['dokter']['alamat']?></p>
                                <p>Poli : <?=$data['dokter']['nama_poli']?></p>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
