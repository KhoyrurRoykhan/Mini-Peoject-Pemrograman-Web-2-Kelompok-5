    </body>
</html>


<!-- Style sementara -->
<style>
    .table1A {
        /* border: 1px solid #000000; */
        width: auto;
        height: 360px;
        
    }

    .table2A{
        /* border: 1px solid #000000; */
        width: auto;
        height: auto;
    }

    .tabel3A {
        /* border: 1px solid #000000; */
        width: 400px;
        height: 10px;
        font-size: 20px;
        font-weight: bold;
        color: #2F8F9D;
        text-align: center;
        background-color: #B3E8E5;
    }

    .tabel4A {
        /* border: 1px solid #000000; */
        width: 400px;
        height: 30px;
        font-size: 15px;
        font-weight: bold;
        text-align: center;
        background-color: #B3E8E5;
    }

    .table1B{
        /* border: 1px solid #000000; */
        width: auto;
        height: 320px;
        padding: 15px;
        background-color: #B3E8E5;
    }

    .table1B p {
        padding: 8px;
        margin: 0;
        font-size: 16px;
        font-weight: bold;
    }
    .nama1A{
        /* border: 1px solid #000000; */
        width: 100px;
        font-size: 25px;
        color: #2F8F9D;
        text-align: center;
        font-weight: bold;
        background-color: #B3E8E5;
    }
</style>