    </body>
</html>

<!-- Style sementara -->
<style>
    /* .paragraf1B{
        border: 1px solid #000000;
    } */

    .table1B{
        /* border: 1px solid #000000; */
        width: auto;
        height: 320px;
        padding: 15px;
        background-color: #B3E8E5;
    }

    .table1B p {
        padding: 8px;
        margin: 0;
        font-size: 16px;
        font-weight: bold;
    }
    .nama1A{
        /* border: 1px solid #000000; */
        width: 100px;
        font-size: 25px;
        color: #2F8F9D;
        text-align: center;
        font-weight: bold;
        background-color: #B3E8E5;
    }
</style>