
                <div class="box2C">
                    <div class="data2C">
                        <h1>MENU DOKTER</h1>
                            <div class="table1A">
                            <table class="table2A">
                                        <tr?>
                                            <td class="tabel3A">ID DOKTER</td>
                                            <td class="tabel3A">NAMA DOKTER</td>
                                            <td class="tabel3A">AKSI</td>
                                        </tr>
                                <?php foreach ($data['dokter'] as $dokter) : ?>
                                    
                                        <tr?>
                                            <td class="tabel4A"><?= $dokter['id_dokter']?></td>
                                            <td class="tabel4A"><?= $dokter['nama_dokter']?></td>
                                            <td class="tabel4A"><a href="<?= BASEURL?>/dokter/detail/<?=$dokter['id_dokter']?>">detail</a></td>
                                        </tr>
                                    
                                <?php endforeach; ?>
                            </table>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
