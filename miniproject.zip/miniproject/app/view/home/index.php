<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/style.css">
</head>

<body class="background1">

    <div class="navbar1">
        <div class="href_login1A">
            <a style="text-decoration:none" href="<?=BASEURL?>/pasien/index"><h1>Pengunjung</h1></a>
        </div>
        <div class="href_login2A">
            <a style="text-decoration:none" href="<?=BASEURL?>/login/index"><h1>Login</h1></a>
        </div>
        
    </div>

    <div class="margin1A">
        <div class="margin2A">
            <div class="logo"></div>
            <h1 class="heading_semalat_datang">SELAMAT DATANG</h1>
            <div class="latar_belakang" class="margin2" style="background-image: url(<?= BASEURL; ?>/img/image-1.png); background-size: cover; text-align: center;"></div>
        </div>
    </div>

</body>
</html>                                 