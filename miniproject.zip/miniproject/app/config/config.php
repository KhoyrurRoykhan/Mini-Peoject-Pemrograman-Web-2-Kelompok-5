<?php 

define('BASEURL', 'http://localhost/miniproject/public');

// DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'onetwo3four5');
define('DB_NAME', 'db_puskesmas');