<?php

class Obat extends Controller{
    public function index(){

        $data['obat'] = $this->model('Obat_model')->getAllObat();
        $data['judul'] = 'Menu Obat';
        $this->view('templates/header', $data );
        $this->view('obat/index',$data);
        $this->view('templates/footer');
    }

    public function detail($id){

        $data['obat'] = $this->model('Obat_model')->getObatById($id);
        $data['judul'] = 'Menu Detail Pasien';
        $this->view('templates/header', $data );
        $this->view('obat/detail',$data);
        $this->view('templates/footer_detail');
    }

    
}