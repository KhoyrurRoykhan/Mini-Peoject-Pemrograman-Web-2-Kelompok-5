<?php

class Petugas extends Controller{
    public function index(){

        $data['petugas'] = $this->model('Petugas_model')->getAllPetugas();
        $data['judul'] = 'Menu Petugas';
        $this->view('templates/header', $data );
        $this->view('petugas/index',$data);
        $this->view('templates/footer');
    }

    public function detail($id){

        $data['petugas'] = $this->model('Petugas_model')->getPetugasById($id);
        $data['judul'] = 'Menu Detail Petugas';
        $this->view('templates/header', $data );
        $this->view('petugas/detail',$data);
        $this->view('templates/footer_detail');
    }

    
}