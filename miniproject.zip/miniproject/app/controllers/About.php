<?php

class About {
    public function index($nama='roy',$pekerjaan='mahasiswa'){
        echo "Halo nama saya $nama saya $pekerjaan";
    }
    public function page(){
        echo 'about/page';
    }
}