<?php

class Dokter extends Controller{
    public function index(){
        $data['dokter'] = $this->model('Dokter_model')->getAllDokter();
        $data['judul'] = 'Menu Dokter';
        $this->view('templates/header', $data );
        $this->view('dokter/index',$data);
        $this->view('templates/footer');
    }
    public function detail($id){
        
        $data['dokter'] = $this->model('Dokter_model')->getDokterById($id);
        $data['judul'] = 'Menu Dokter';
        $this->view('templates/header', $data );
        $this->view('dokter/detail',$data);
        $this->view('templates/footer_detail');

    }
}