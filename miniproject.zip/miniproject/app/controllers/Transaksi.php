<?php

class Transaksi extends Controller{
    public function index(){

        $data['transaksi'] = $this->model('transaksi_model')->getAllTransaksi();
        $data['judul'] = 'Menu Transaksi';
        $this->view('templates/header', $data );
        $this->view('transaksi/index',$data);
        $this->view('templates/footer');
    }

    public function detail($id){

        $data['transaksi'] = $this->model('transaksi_model')->getTransaksiById($id);
        $data['judul'] = 'Menu Detail Berkas';
        $this->view('templates/header', $data );
        $this->view('transaksi/detail',$data);
        $this->view('templates/footer_detail');
    }

    
}