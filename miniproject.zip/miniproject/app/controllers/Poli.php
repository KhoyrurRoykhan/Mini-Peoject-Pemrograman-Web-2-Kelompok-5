<?php

class Poli extends Controller{

    public function index() {

        $data['poli'] = $this->model('Poli_model')->getAllPoli();
        $data['judul'] = 'Menu Poli';
        $this->view('templates/header', $data );
        $this->view('poli/index',$data);
        $this->view('templates/footer');
    }

    public function detail($id){

        $data['poli'] = $this->model('Poli_model')->getPoliById($id);
        $data['judul'] = 'Menu Poli';
        $this->view('templates/header', $data );
        $this->view('poli/detail',$data);
        $this->view('templates/footer_detail');
    }
}