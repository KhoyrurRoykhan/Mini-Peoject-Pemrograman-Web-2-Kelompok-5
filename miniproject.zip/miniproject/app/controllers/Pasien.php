<?php

class Pasien extends Controller{
    public function index(){

        $data['pasien'] = $this->model('Pasien_model')->getAllPasien();
        $data['judul'] = 'Menu Obat';
        $this->view('templates/header', $data );
        $this->view('pasien/index',$data);
        $this->view('templates/footer');
    }

    public function detail($id){

        $data['pasien'] = $this->model('Pasien_model')->getPasienById($id);
        $data['judul'] = 'Menu Detail Pasien';
        $this->view('templates/header', $data );
        $this->view('pasien/detail',$data);
        $this->view('templates/footer_detail');
    }

    
}