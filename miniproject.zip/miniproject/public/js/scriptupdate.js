$(function() {
    $('.tombolTambahData').on('click', function(){
        $('#judulModal').html('Tambah Data');
        $('.modal-footer button[type=submit]').html('Tambah Data');
    })

    $('.tampilModalUbah').on('click', function(){
        $('#judulModal').html('Ubah Data');
        $('.modal-footer button[type=submit]').html('Ubah Data');

        let id_o = $(this).data('id');
        console.log(id_o);
    });

});